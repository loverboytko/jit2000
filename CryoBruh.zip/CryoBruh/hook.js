function callback(details) { 
    console.trace(details);

    chrome.tabs.executeScript(details.tabId, {
		file: 'script.js'
    });
    
    const file = details.url.substring(details.url.lastIndexOf('/') + 1);
    return {
        //cancel: true, /*Cannot cancel while other methods*/
        redirectUrl: chrome.runtime.getURL(file)
    }; 
}

chrome.webRequest.onBeforeRequest.addListener(callback,
    {urls: ["*://play.bruh.io/main.8c81f068.js"],
    types: ["script"]},//, "xmlhttprequest"
    ["blocking"]);